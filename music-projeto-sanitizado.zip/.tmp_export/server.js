require('dotenv').config();
const express = require('express');
const cors = require('cors');
const multer = require('multer');
const mm = require('music-metadata');
const { createClient } = require('@supabase/supabase-js');

const app = express();

function normalizarValor(valor, fallback = '') {
  if (Array.isArray(valor)) {
    return valor[0] || fallback;
  }

  if (typeof valor === 'string') {
    const text = valor.trim();
    return text || fallback;
  }

  return fallback;
}

async function lerMetadadosMp3(file) {
  try {
    const metadata = await mm.parseBuffer(file.buffer, { mimeType: file.mimetype || 'audio/mpeg' });
    const common = metadata.common || {};

    return {
      title: normalizarValor(common.title, file.originalname.replace(/\.[^/.]+$/, '') || 'Música sem título'),
      artist: normalizarValor(common.artist, 'Artista desconhecido'),
      genre: normalizarValor(common.genre, 'Gênero não informado')
    };
  } catch (error) {
    return {
      title: file.originalname.replace(/\.[^/.]+$/, '') || 'Música sem título',
      artist: 'Artista desconhecido',
      genre: 'Gênero não informado'
    };
  }
}

// Middlewares
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve os arquivos da pasta atual (index.html, style.css, etc.)
app.use(express.static(__dirname));

// Conexão com o Supabase
const SUPABASE_URL = process.env.SUPABASE_URL;
const SUPABASE_KEY = process.env.SUPABASE_KEY;
const supabase = createClient(SUPABASE_URL, SUPABASE_KEY);

// Configuração do Multer (grava na memória antes de enviar ao Supabase)
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 15 * 1024 * 1024 }, // Limite de 15MB
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'audio/mpeg' || file.mimetype === 'audio/mp3') {
      cb(null, true);
    } else {
      cb(new Error('Apenas arquivos MP3 são permitidos!'));
    }
  }
});

app.get('/musicas', async (req, res) => {
  try {
    const { data, error } = await supabase
      .from('musicas')
      .select('*')
      .order('id', { ascending: false });

    if (error) throw error;

    return res.json({ musicas: data || [] });
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

// Rota de Upload
app.post('/upload', upload.single('audio'), async (req, res) => {
  try {
    const { title, artist, genre } = req.body;
    const file = req.file;

    if (!file) {
      return res.status(400).json({ error: 'Nenhum arquivo de áudio foi enviado.' });
    }

    const metadados = await lerMetadadosMp3(file);
    const tituloFinal = title || metadados.title;
    const artistaFinal = artist || metadados.artist;
    const generoFinal = genre || metadados.genre;

    // Nome único para o arquivo MP3
    const nomeArquivo = `${Date.now()}-${file.originalname.replace(/\s+/g, '_')}`;

    // 1. Envia o arquivo MP3 para o bucket 'musicas'
    const { error: storageError } = await supabase.storage
      .from('musicas')
      .upload(nomeArquivo, file.buffer, {
        contentType: file.mimetype
      });

    if (storageError) throw storageError;

    // 2. Pega a URL pública do arquivo MP3
    const { data: publicUrlData } = supabase.storage
      .from('musicas')
      .getPublicUrl(nomeArquivo);

    const urlAudio = publicUrlData.publicUrl;

    // 3. Salva os metadados na tabela 'musicas'
    const { data: dbData, error: dbError } = await supabase
      .from('musicas')
      .insert([
        {
          titulo: tituloFinal,
          artista: artistaFinal,
          genero: generoFinal,
          url_audio: urlAudio
        }
      ])
      .select();

    if (dbError) throw dbError;

    const musicaRetornada = {
      id: dbData[0]?.id ?? null,
      title: dbData[0]?.titulo ?? tituloFinal,
      artist: dbData[0]?.artista ?? artistaFinal,
      genre: dbData[0]?.genero ?? generoFinal,
      audio_url: dbData[0]?.url_audio ?? urlAudio
    };

    return res.status(201).json({
      mensagem: 'Música cadastrada com sucesso!',
      musica: musicaRetornada
    });

  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
});

// Inicialização do Servidor (Render usa a variável PORT automática)
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta http://localhost:${PORT}`);
});