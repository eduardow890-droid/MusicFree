
    lucide.createIcons();

    const fileInput = document.getElementById('audio-file');
    const fileNameDisplay = document.getElementById('file-name-display');
    const form = document.getElementById('upload-form');
    const submitBtn = document.getElementById('submit-btn');
    const playerTitle = document.getElementById('player-title');
    const playerArtist = document.getElementById('player-artist');
    const audioElement = document.getElementById('audio-player');
    const playBtn = document.getElementById('play-btn');
    const nextBtn = document.getElementById('next-btn');
    const previousBtn = document.getElementById('previous-btn');
    const libraryList = document.getElementById('library-list');
    const refreshLibraryBtn = document.getElementById('refresh-library');
    const navItems = document.querySelectorAll('.nav-item');
    const views = {
      upload: document.getElementById('view-upload'),
      library: document.getElementById('view-library')
    };

    const appState = {
      tracks: [],
      currentIndex: -1
    };

    function setView(viewName) {
      Object.entries(views).forEach(([key, section]) => {
        section.classList.toggle('active', key === viewName);
      });

      navItems.forEach((item) => {
        item.classList.toggle('active', item.dataset.view === viewName);
      });
    }

    function normalizeTrack(track) {
      return {
        id: track.id,
        title: track.titulo || track.title || 'Sem título',
        artist: track.artista || track.artist || 'Artista desconhecido',
        genre: track.genero || track.genre || 'Gênero não informado',
        audio_url: track.url_audio || track.audio_url
      };
    }

    function updatePlayer(track) {
      if (!track) {
        playerTitle.textContent = 'Nenhuma música selecionada';
        playerArtist.textContent = 'Aguardando upload';
        audioElement.removeAttribute('src');
        return;
      }

      playerTitle.textContent = track.title;
      playerArtist.textContent = track.artist;
      audioElement.src = track.audio_url;
      audioElement.play().catch(() => {});
      updatePlayButton(true);
    }

    function updatePlayButton(isPlaying) {
      const icon = playBtn.querySelector('i');
      icon.setAttribute('data-lucide', isPlaying ? 'pause' : 'play');
      lucide.createIcons();
    }

    function playSelectedTrack(index) {
      if (!appState.tracks.length) return;

      const safeIndex = (index + appState.tracks.length) % appState.tracks.length;
      appState.currentIndex = safeIndex;
      const track = appState.tracks[safeIndex];
      updatePlayer(track);
    }

    function renderLibrary() {
      libraryList.innerHTML = '';

      if (!appState.tracks.length) {
        libraryList.innerHTML = '<div class="empty-state">Nenhuma música salva ainda. Faça o upload da primeira faixa.</div>';
        return;
      }

      appState.tracks.forEach((track, index) => {
        const item = document.createElement('article');
        item.className = 'library-item';

        item.innerHTML = `
          <div class="library-cover"><i data-lucide="music"></i></div>
          <div>
            <h3>${track.title}</h3>
            <p>${track.artist}</p>
            <p>${track.genre}</p>
          </div>
          <button type="button">Reproduzir</button>
        `;

        const button = item.querySelector('button');
        button.addEventListener('click', () => {
          playSelectedTrack(index);
          setView('upload');
        });

        libraryList.appendChild(item);
      });

      lucide.createIcons();
    }

    async function loadLibrary() {
      try {
        const response = await fetch('/musicas');
        const data = await response.json();

        appState.tracks = (data.musicas || []).map(normalizeTrack);
        renderLibrary();
      } catch (error) {
        console.error('Erro ao carregar biblioteca:', error);
        libraryList.innerHTML = '<div class="empty-state">Não foi possível carregar a biblioteca no momento.</div>';
      }
    }

    fileInput.addEventListener('change', (e) => {
      if (e.target.files.length > 0) {
        fileNameDisplay.textContent = `Arquivo selecionado: ${e.target.files[0].name}`;
      } else {
        fileNameDisplay.textContent = 'Arraste seu arquivo MP3 aqui';
      }
    });

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      submitBtn.disabled = true;
      submitBtn.textContent = 'Enviando para o Supabase...';

      const formData = new FormData(form);

      try {
        const response = await fetch('/upload', {
          method: 'POST',
          body: formData
        });

        const result = await response.json();

        if (response.ok) {
          const musica = result.musica || result.song;
          const track = normalizeTrack(musica);

          appState.tracks.unshift(track);
          renderLibrary();
          updatePlayer(track);
          form.reset();
          fileNameDisplay.textContent = 'Arraste seu arquivo MP3 aqui';
          alert('🎵 Música enviada e cadastrada com sucesso!');
        } else {
          alert(`Erro: ${result.error || 'Não foi possível fazer o upload.'}`);
        }
      } catch (error) {
        console.error('Erro na requisição:', error);
        alert('Erro ao se conectar ao servidor local. Tente novamente!');
      } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = 'Salvar no Banco de Dados';
      }
    });

    navItems.forEach((item) => {
      item.addEventListener('click', () => {
        setView(item.dataset.view);
      });
    });

    refreshLibraryBtn.addEventListener('click', loadLibrary);

    playBtn.addEventListener('click', () => {
      if (!audioElement.src) {
        if (appState.tracks.length) {
          playSelectedTrack(0);
        }
        return;
      }

      if (audioElement.paused) {
        audioElement.play().catch(() => {});
        updatePlayButton(true);
      } else {
        audioElement.pause();
        updatePlayButton(false);
      }
    });

    nextBtn.addEventListener('click', () => {
      if (appState.tracks.length) {
        playSelectedTrack(appState.currentIndex + 1);
      }
    });

    previousBtn.addEventListener('click', () => {
      if (appState.tracks.length) {
        playSelectedTrack(appState.currentIndex - 1);
      }
    });

    audioElement.addEventListener('play', () => updatePlayButton(true));
    audioElement.addEventListener('pause', () => updatePlayButton(false));
    audioElement.addEventListener('ended', () => {
      if (appState.tracks.length) {
        playSelectedTrack(appState.currentIndex + 1);
      }
    });

    setView('upload');
    loadLibrary();
    updatePlayButton(false);